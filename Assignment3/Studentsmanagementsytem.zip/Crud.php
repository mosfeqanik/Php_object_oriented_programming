<?php  

interface Crud
{


	public function save($name,$email,$phone);
	public function read();
	
}






?>